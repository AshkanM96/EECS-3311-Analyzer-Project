- analyzer_events.txt 
	Use this file to generate an ETF project into the current directory.
	
- at1.txt, at2.txt., ..., at5.txt 
	These five files contain example use cases of the analyzer application. 
	
- at1.expected.txt, at2.expected.txt, ..., at5.expected.txt 
	These five files are the expected outputs of your analyzer software being run on the example use cases.  